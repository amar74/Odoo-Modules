# -*- coding: utf-8 -*-
{
    'name': 'contact_form',
    'description': 'Contact_form',
    'author': 'Amarnath Rana',
    'depends': ['todo_user'],

    'data': [
        'views/form_views.xml'],
}
