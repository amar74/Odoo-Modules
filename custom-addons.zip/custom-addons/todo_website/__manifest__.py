{
  'name':'To-Do Webste',
  'description':'To-Do Task Website',
  'author':'Amarnath Rana',
  'depends': ['todo_kanban']
  'data':  ['views/todoo_templates.xml','views/todo_extend.xml']
}
