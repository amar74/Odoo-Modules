{
  'name': 'To-Do Report',
  'description': 'Report for To-Do task.',
  'author': 'Amarnath Rana',
  'depends': ['todo_kanban'],
  'data': ['reports/todo_report.xml','reports/todo_model_report.xml']

}
