{
 'name': 'Inherit Employee',
 'description': 'Add new Tab on Employee form',
 'Author': 'Amarnath Rana',
 'depends': ['base','hr','crm'],
 'data': ['views/emp.xml']
}
