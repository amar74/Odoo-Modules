{
 'name': 'User interface improvements to To-Do app',
 'description': 'User friendly features.',
 'author': 'Amarnath Rana',
 'depends': ['todo_user'],
 'data': [ 'views/todo_menu.xml','views/todo_view.xml',],
 'application':True,
}
