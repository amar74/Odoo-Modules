{
  'name':'To-Kanban1',
  'description': 'Todo-Kanban-view'
  'author': 'Amarnath Rana'
  'depends': 'Todo-user'
  'data': ['views/todo_kanban1.xml']
}
