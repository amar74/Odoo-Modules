{

 'name': 'HRMS Scope of wor',
 'description': 'Employee hiring form',
 'author': 'Amarnath Rana',
 'data': ['views/employee.xml','views/mail.xml']
 
}
