{
 'name':'Employee Model',
 'description':'Inhrit Models & views from Employee module',
 'author': 'Amarnath Rana',
 'depends': ['base','hr'],
 'data': ['views/emply.xml']
}
