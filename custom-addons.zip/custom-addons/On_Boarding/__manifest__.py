{
 'name': 'ON BOARDING',
 'description': 'Hired Employee',
 'author': 'Amarnath Rana',
 'depends': ['base', 'hr'],
 'data': ['views/Onboard.xml']
}
