{
  'name': 'To-Do Kanban',
  'description': 'Kanban board for to-do tasks.',
  'author': 'Amarnath Rana',
  'depends':['todo_ui'],
  'data': ['views/todo_view.xml','views/todo_kanban_assets.xml']
}
