{
	'name' : 'Contact App v1.0.0',
	'description' : 'This app will display contact info for a prospect',
	'author' : 'Rob Burger',
	'depends' : 'website',
	'summary' : 'Template',
	'website' : 'www.github.com',
	#'data' : []
}